import * as React from "react";
import { PropertyControls, ControlType } from "framer";
import { Helmet } from "react-helmet";
import { throws } from "assert";

// Define type of property
interface Props {
  text: string;
  font: string;
  size: number;
  weight: number;
  color: string;
  style: string;
  spacing: number;
  line: number;
  align: "left" | "center" | "right" | "justify" | "start" | "end";
  direction: "ltr" | "rtl";
  width: number;
  height: number;
}

export class WebFont extends React.Component<Props> {
  static defaultProps = {
    text: "Festina Lente",
    font: "Work Sans",
    weight: "700",
    size: 40,
    color: "#000",
    style: "normal",
    spacing: 0,
    line: 1,
    align: "center",
    direction: "ltr",
  };

  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: "Text" },
    font: { type: ControlType.String, title: "Font" },
    color: { type: ControlType.Color, title: "Color" },
    size: { type: ControlType.Number, title: "Size", min: 0, max: 500 },
    weight: {
      type: ControlType.Enum,
      title: "Weight",
      options: ["100", "200", "300", "400", "500", "600", "700", "800"],
    },
    style: {
      type: ControlType.Enum,
      title: "Style",
      options: ["normal", "italic", "oblique"],
      optionTitles: ["Normal", "Italic", "Oblique"],
    },
    align: {
      type: ControlType.Enum,
      title: "Align",
      options: ["left", "center", "right", "justify", "start", "end"],
      optionTitles: ["Left", "Center", "Right", "Justify", "Start", "End"],
    },
    direction: {
      type: ControlType.Enum,
      title: "Direction",
      options: ["ltr", "rtl"],
      optionTitles: ["Left to Right", "Right to Left"],
    },

    spacing: {
      type: ControlType.Number,
      title: "Spacing",
      min: -30,
      max: 30,
      step: 0.1,
    },
    line: {
      type: ControlType.Number,
      title: "Line",
      min: 0,
      max: 5,
      step: 0.1,
    },
  };

  render() {
    const weight = Number.parseInt(`${this.props.weight}`);
    const style: React.CSSProperties = {
      display: "flex",
      height: "100%",
      alignItems: "center",
      justifyContent: "center",
      flexDirection: "column",
      color: `${this.props.color}`,
      fontSize: `${this.props.size}px`,
      fontFamily: `${this.props.font}`,
      fontWeight: weight,
      fontStyle: `${this.props.style}`,
      letterSpacing: `${this.props.spacing}px`,
      lineHeight: `${this.props.line}`,
      textAlign: `${this.props.align}` as
        | "left"
        | "center"
        | "right"
        | "justify"
        | "start"
        | "end",
      direction: `${this.props.direction}` as "ltr" | "rtl",
    };
    return (
      <>
        <Helmet>
          <link
            href={`https://fonts.googleapis.com/css?family=${this.props.font}`}
            rel="stylesheet"
          />
        </Helmet>
        <div style={style}>{this.props.text}</div>
      </>
    );
  }
}
