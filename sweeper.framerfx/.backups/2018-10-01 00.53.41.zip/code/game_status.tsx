import * as React from "react";
import { PropertyControls, ControlType } from "framer";

const style: React.CSSProperties = {
    height: "100%",
    display: "flex",
    alignItems: "center",
    flexDirection: "column",
    justifyContent: "center",
    textAlign: "center",
    color: "white",
    border:"3px solid",
    borderTopColor: "#7B7B7B",
    borderLeftColor: "#7B7B7B",
    borderRightColor: "#fff",
    borderBottomColor: "#fff",
    fontFamily: 'VT323',
    overflow: "hidden",
};

// Define type of property
interface Props {
    text: string;
}

export class game_status extends React.Component<Props> {

    // Set default properties
    static defaultProps = {
        text: ""
    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
        text: { type: ControlType.String, title: "Text" },
    }

    render() {
        return <div style={style}>
            <div>Points</div>
            <div>Status</div>
            <div>Start over?</div>
        </div>;
    }
}
