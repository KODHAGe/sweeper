import * as React from "react";
import { PropertyControls, ControlType } from "framer";

const style: React.CSSProperties = {
    display: "flex",
    flexGrow: 1,
    alignItems: "center",
    flexDirection: "column",
    justifyContent: "center",
    textAlign: "center",
    color: "white",
    border:"4px solid",
    borderTopColor: "#7B7B7B",
    borderLeftColor: "#7B7B7B",
    borderRightColor: "#fff",
    borderBottomColor: "#fff",
    fontFamily: 'VT323',
    overflow: "hidden",
};

// Define type of property
interface Props {
    points: number,
    status: string
}

export class GameStatus extends React.Component<Props> {

    // Set default properties
    static defaultProps = {
        points: 0,
        status: "Alive"
    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
        text: { type: ControlType.String, title: "Text" },
    }


    reloadGame() {
        location.reload()
    }

    render() {
        return <div style={style}>
            <div>Points: {this.props.points}</div>
            <div>Status: {this.props.status}</div>
            <div onClick={this.reloadGame}>Start over?</div>
        </div>;
    }
}
