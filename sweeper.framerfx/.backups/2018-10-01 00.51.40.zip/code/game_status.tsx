import * as React from "react";
import { PropertyControls, ControlType } from "framer";

const style: React.CSSProperties = {
    height: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    textAlign: "center",
    color: "#8855FF",
    border:"3px solid",
    borderTopColor: "#7B7B7B",
    borderLeftColor: "#7B7B7B",
    borderRightColor: "#fff",
    borderBottomColor: "#fff",
    overflow: "hidden",
};

// Define type of property
interface Props {
    text: string;
}

export class game_status extends React.Component<Props> {

    // Set default properties
    static defaultProps = {
        text: ""
    }

    // Items shown in property panel
    static propertyControls: PropertyControls = {
        text: { type: ControlType.String, title: "Text" },
    }

    render() {
        return <div style={style}>{this.props.text}</div>;
    }
}
